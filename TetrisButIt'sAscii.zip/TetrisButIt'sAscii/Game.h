#include <iostream>
#include <windows.h>
#include <string>
#include <thread>
#include <chrono>
#include <functional>
#include "Tetromino.h"
#include "timercpp.h"
class Game {
	enum State {left, right, down};
	char cmatrix[26][14];
	int score;
	void clear_screen(char fill = ' ') {
		COORD tl = { 0,0 };
		CONSOLE_SCREEN_BUFFER_INFO s;
		HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
		GetConsoleScreenBufferInfo(console, &s);
		DWORD written, cells = s.dwSize.X * s.dwSize.Y;
		FillConsoleOutputCharacter(console, fill, cells, tl, &written);
		FillConsoleOutputAttribute(console, s.wAttributes, cells, tl, &written);
		SetConsoleCursorPosition(console, tl);
	}

	void prepPlayField() {
		for (int x = 0; x < 26; x++) {
			for (int y = 0; y < 12; y++) {
				cmatrix[x][y] = '/';
			}
		}
		for (int x = 0; x < 26; x++) {
			cmatrix[x][12] = '\0';
			cmatrix[x][0] = '[';
			cmatrix[x][11] = ']';
		}
	}

	void tetrominoDisplayer() {
		clear_screen();
		for (int x = 21; x != 0; x--) {
			printf("%s", cmatrix[x]);
			printf("\n");
		}
		std::cout << "\n\nScore: " + std::to_string(score);
		printf("\n");
	}

	void BlockDoFall() {

	}

	/*void fn() { //This is simply responsible for moving the tetrominoes down
		for (;;) {
			std::this_thread::sleep_for(std::chrono::milliseconds(50));
		}
	}*/
	void ChangePosition(int& x1, int& y1, int& x2, int& y2, int& x3, int& y3, int& x4, int& y4, int Direction, Tetromino& a) {
		switch (Direction) {
			case 0:
				a.Left();
				break;
			case 1:
				a.Right();
				break;
			case 2: //setpos shit
				if (a.CanIFall == true) {
					a.Down();
				}
				else {
					Tetromino a;
					goto Quickend;
				}
				break;
		}
		cmatrix[y1][x1] = '/';
		cmatrix[y2][x2] = '/';
		cmatrix[y3][x3] = '/';
		cmatrix[y4][x4] = '/';		
		a.getPos(x1, y1, x2, y2, x3, y3, x4, y4);
		cmatrix[y1][x1] = '#';
		cmatrix[y2][x2] = '#';
		cmatrix[y3][x3] = '#';
		cmatrix[y4][x4] = '#';
		tetrominoDisplayer();
	Quickend:
	}
public: 
	Game() {
		prepPlayField();
		score = 0;
	}
	void startgame() {
		State state;

		Tetromino a;
		int x1, y1, x2, y2, x3, y3, x4, y4;
	
		a.getPos(x1, y1, x2, y2, x3, y3, x4, y4);
		cmatrix[y1][x1] = '#';
		cmatrix[y2][x2] = '#';
		cmatrix[y3][x3] = '#';
		cmatrix[y4][x4] = '#';
		Timer t = Timer();
		tetrominoDisplayer();
		t.setInterval([&]() {
			state = down;
			
			/*cmatrix[y1][x1] = '/';
			cmatrix[y2][x2] = '/';
			cmatrix[y3][x3] = '/';
			cmatrix[y4][x4] = '/';
			a.getPos(x1, y1,x2,y2,x3,y3,x4,y4);
			a.setPos();
			cmatrix[y1][x1] = '#';
			cmatrix[y2][x2] = '#';
			cmatrix[y3][x3] = '#';
			cmatrix[y4][x4] = '#';*/
			}, 500);
		//std::cout << std::to_string(x1) << std::to_string(y1)<< std::to_string(x2)<< std::to_string(y2)<< std::to_string(x3)<< std::to_string(y3)<< std::to_string(x4)<< std::to_string(y4);
		while (1 == 1) {
			if (GetKeyState(VK_LEFT) & 0x8000) {
				state = left;				
				Sleep(10);
				ChangePosition(x1, y1, x2, y2, x3, y3, x4, y4, state, a);
			}
			else if ((GetKeyState(VK_RIGHT)) & 0x8000) {
				state = right;
				Sleep(10);
				ChangePosition(x1, y1, x2, y2, x3, y3, x4, y4, state, a);

			}
			else if ((GetKeyState(VK_DOWN)) & 0x8000) {
				state = down;
				Sleep(10);
				ChangePosition(x1, y1, x2, y2, x3, y3, x4, y4, state, a);
			}
		}
	}
};


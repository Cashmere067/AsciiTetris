#pragma once
#include <random>
class Tetromino {
	int startint;
	int type;
	bool IsControlled;
	int Block[4][2];

	void RandomiseBlock() {
		type = rand() % 7;
		switch (type) {
		case 0: //"longboi"
			for (int x = 0; x < 4; x++) {
				Block[x][0] = 4 + x;
				Block[x][1] = 21;
			}
			break;
		case 1: //L piece Left
			Block[0][0] = 4; Block[0][1] = 22;//High boi
			for (int x = 1; x < 4; x++) {
				Block[x][0] = 4 + x;
				Block[x][1] = 21;
			}
			break;
		case 2: //L piece Right
			Block[3][0] = 6; Block[3][1] = 22;//High boi
			for (int x = 0; x < 3; x++) {
				Block[x][0] = 4 + x;
				Block[x][1] = 21;
			}
			break;
		case 3: // CEWB
			Block[0][0] = 5; Block[0][1] = 21;
			Block[1][0] = 5; Block[1][1] = 22;
			Block[2][0] = 6; Block[2][1] = 21;
			Block[3][0] = 6; Block[3][1] = 22;
			break;
		case 4: //Squiggly right
			Block[0][0] = 4; Block[0][1] = 21;
			Block[1][0] = 5; Block[1][1] = 21;
			Block[2][0] = 5; Block[2][1] = 22;
			Block[3][0] = 6; Block[3][1] = 22;
			break;
		case 5: //Squiggly left
			Block[0][0] = 4; Block[0][1] = 22;
			Block[1][0] = 5; Block[1][1] = 22;
			Block[2][0] = 5; Block[2][1] = 21;
			Block[3][0] = 6; Block[3][1] = 21;
			break;
		case 6: //T ass
			Block[0][0] = 4; Block[0][1] = 21;
			Block[1][0] = 5; Block[1][1] = 21;
			Block[2][0] = 6; Block[2][1] = 21;
			Block[3][0] = 5; Block[3][1] = 22;
		}
	}
public:
	Tetromino() {
		startint = 21;
		IsControlled = true;
		RandomiseBlock();
	}
	void setPos(int y1, int y2, int y3, int y4) {
		Block[0][1] = y1;
		Block[1][1] = y2;
		Block[2][1] = y3;
		Block[3][1] = y4;
	}
	void getPos(int &x1, int &y1, int &x2,int &y2,int &x3,int &y3,int &x4,int &y4) {
		x1 = Block[0][0]; y1 = Block[0][1];
		x2 = Block[1][0]; y2 = Block[1][1];
		x3 = Block[2][0]; y3 = Block[2][1];
		x4 = Block[3][0]; y4 = Block[3][1];
	}
	void Left() {
		int c = 0;
		for (int i = 0; i < 4; i++) {
			if (Block[i][0] == 1) {
				c++;
			}
		}
		if (c == 0) {
			for (int i = 0; i < 4; i++) {
				Block[i][0]--;
			}
		}
	}
	void Right() {
		int c = 0;
		for (int i = 0; i < 4; i++) {
			if (Block[i][0] == 10) {
				c++;
			}
		}
		if (c == 0) {
			for (int i = 0; i < 4; i++) {
				Block[i][0]++;
			}
		}	
	}
	void Down() {
		int c = 0;
		for (int i = 0; i < 4; i++) {
			if (Block[i][1] == 0) {
				c++;
			}
		}
		if (c == 0) {
			for (int i = 0; i < 4; i++) {
				Block[i][1]--;
			}
		}
	}
	bool CanIFall() {
		/*int Kek[4];
		for (int i = 0; i < 4; i++) {
			Kek[i] = 0;
		}

		for (int i = 0; i < 4; i++) {
			if (Block[i][0] == Block[0][0]) { Kek[0]++; } //checks if any are the same
			if (Block[i][0] == Block[1][0]) { Kek[1]++; }
			if (Block[i][0] == Block[2][0]) { Kek[2]++; }
			if (Block[i][0] == Block[3][0]) { Kek[3]++; } //just find if any of them are the same first.
		}
		for (int i = 0; i < 4; i++) {
			if (Kek[i] > 1) {

			}
		}*/
		return true;
	}
};

